const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const cp = require('node:child_process');
const root = path.join(__dirname, 'review');
const out = path.join(__dirname, 'review-evidence');
fs.mkdirSync(out, { recursive: true });
async function main() {
 const s = net.createServer();
 await new Promise((resolve, reject) => s.listen(0, '127.0.0.1', resolve).on('error', reject));
 const port = s.address().port;
 await new Promise(r=>s.close(r));
 const env = {...process.env, CI:'1', E2E_PORT:String(port), TMP:'C:/Users/mas/AppData/Local/hermes/cache/scratch', TEMP:'C:/Users/mas/AppData/Local/hermes/cache/scratch', TMPDIR:'C:/Users/mas/AppData/Local/hermes/cache/scratch', PLAYWRIGHT_JSON_REPORT:path.join(out,'playwright.json')};
 const results=[];
 for (const [name,cmd] of [['all','npm run test:all'],['lint','npm run lint'],['format','npm run format:check'],['verify','npm run verify:build']]) {
  const fd=fs.openSync(path.join(out, name+'.log'),'w');
  const started=new Date().toISOString();
  const r = cp.spawnSync(cmd, {cwd:root, env, shell:true, stdio:['ignore',fd,fd], timeout:320000});
  fs.closeSync(fd);
  results.push({name,cmd,status:r.status,error:r.error?.message,started,finished:new Date().toISOString(),port});
  fs.writeFileSync(path.join(out,'gate-results.json'),JSON.stringify(results,null,2));
  console.log(name, 'exit',r.status, r.error?.message||'');
  console.log(fs.readFileSync(path.join(out,name+'.log'),'utf8').slice(-2500));
 }
}
main().catch(e=>{console.error(e);process.exitCode=1;});

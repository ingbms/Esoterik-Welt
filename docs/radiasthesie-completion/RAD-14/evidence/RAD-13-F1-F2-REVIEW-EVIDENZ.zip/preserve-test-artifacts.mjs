import fs from 'node:fs';
import path from 'node:path';
import cp from 'node:child_process';
const root=path.resolve('review'),out=path.resolve('review-evidence');
const git=(args)=>cp.execFileSync('git',args,{cwd:root,encoding:'utf8'});
const status=git(['status','--porcelain=v1','-z']);
const entries=status.split('\0').filter(Boolean);
const names=entries.map(x=>x.slice(3));
for(const n of names)if(!/^(Lokal(?:-(?:404|datenschutz|haftung|impressum))?\.html|radiasthesie\/[a-z]+\.html|sitemap\.xml|docs\/radiasthesie-completion\/RAD-(?:08|09|10)\/evidence\/.+\.(?:png|pdf))$/.test(n))throw new Error('Unexpected file; will not restore '+n);
fs.writeFileSync(path.join(out,'generated-diff.txt'),git(['diff','--ignore-space-at-eol','--stat']));
for(const n of names){const target=path.join(out,'test-generated',n);fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(path.join(root,n),target);}
if(names.length)git(['restore','--worktree','--',...names]);
const final=git(['status','--porcelain=v1']);
fs.writeFileSync(path.join(out,'final-status.json'),JSON.stringify({restoredOnlyReviewerGenerated:names,reviewWorkingTreeStatus:final,head:git(['rev-parse','HEAD']).trim(),sourceStatus:cp.execFileSync('git',['status','--porcelain=v1'],{cwd:'C:/Users/mas/Arbeit/esow-rad-t_878c59c7',encoding:'utf8'})},null,2));
console.log('Preserved/reverted reviewer test artifacts:',names.length,'review checkout clean:',final==='');
if(final)throw new Error(final);

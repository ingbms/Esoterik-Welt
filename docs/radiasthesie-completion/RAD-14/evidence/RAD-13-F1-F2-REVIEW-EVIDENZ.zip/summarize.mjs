import fs from 'node:fs';
import path from 'node:path';
import cp from 'node:child_process';
const dir=process.cwd(), ev=path.join(dir,'review-evidence');
const probe=JSON.parse(fs.readFileSync(path.join(ev,'probe.json')));
const pw=JSON.parse(fs.readFileSync(path.join(ev,'playwright.json')));
const all=fs.readFileSync(path.join(ev,'all.log'),'utf8');
const suiteCounts=[...all.matchAll(/ℹ tests (\d+)[\s\S]*?ℹ pass (\d+)[\s\S]*?ℹ fail (\d+)[\s\S]*?ℹ cancelled (\d+)[\s\S]*?ℹ skipped (\d+)/g)].map(m=>({tests:+m[1],pass:+m[2],fail:+m[3],cancelled:+m[4],skip:+m[5]}));
const git=(args,cwd=path.join(dir,'review'))=>cp.execFileSync('git',args,{cwd,encoding:'utf8'}).trim();
const source='C:/Users/mas/Arbeit/esow-rad-t_878c59c7';
const result={
 sha:git(['rev-parse','HEAD']), node:process.version, browser:probe.browser,axeVersion:[...new Set(probe.axe.map(r=>r.version))],
 axeRuns:probe.axe.length,axeViolations:probe.axe.reduce((a,r)=>a+r.violations.reduce((b,v)=>b+v.count,0),0),
 checkedLinkInstances:probe.axe.reduce((a,r)=>a+r.checks.length,0),
 imageRuns:probe.images.length,imageInstances:probe.images.reduce((a,r)=>a+r.rows.length,0),
 photoIds:[...new Set(probe.images.flatMap(r=>r.rows.map(i=>i.id)))],
 imageFailures:probe.failures,errors:probe.errors,
 sizesAt728:probe.images.filter(r=>r.width===728).flatMap(r=>r.rows.map(i=>({route:r.route,id:i.id,pixels:i.actualPixels,css:i.cssWidth}))),
 playwright:pw.stats,nodeSuites:suiteCounts,nodeTotals:suiteCounts.reduce((a,r)=>Object.fromEntries(Object.keys(r).map(k=>[k,(a[k]||0)+r[k]])),{}),
 gates:JSON.parse(fs.readFileSync(path.join(ev,'gate-results.json'))),
 initialReviewStatus:'clean after checkout and reverting temporary autocrlf override; before build/test',
 reviewStatusAfterTests:git(['status','--porcelain=v1']),sourceStatus:git(['status','--porcelain=v1'],source),
};
const old=JSON.parse(fs.readFileSync('C:/Users/mas/AppData/Local/hermes/cache/scratch/rad13-evidence/a11y-probe.json'));
result.originalScriptExtraFindings=old.findings;
fs.writeFileSync(path.join(ev,'summary.json'),JSON.stringify(result,null,2));
console.log(JSON.stringify(result,null,2));

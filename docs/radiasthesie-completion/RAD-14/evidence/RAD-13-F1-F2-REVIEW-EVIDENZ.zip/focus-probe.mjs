import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const DIR=path.dirname(fileURLToPath(import.meta.url));
const ROOT=path.join(DIR,'review');
const OUT=path.join(DIR,'review-evidence');
const require=createRequire(path.join(ROOT,'package.json'));
const {chromium}=require('playwright');
const AXE=await readFile('C:/Users/mas/Arbeit/esow-qa-rad13/node_modules/axe-core/axe.min.js','utf8');
const types={'.js':'text/javascript','.json':'application/json','.html':'text/html; charset=utf-8','.css':'text/css','.svg':'image/svg+xml','.avif':'image/avif','.webp':'image/webp','.woff2':'font/woff2'};
const srv=createServer(async(req,res)=>{try{
 let rel=new URL(req.url,'http://localhost').pathname;
 if(!rel.startsWith('/Esoterik-Welt/')){res.writeHead(404).end();return;}
 rel=decodeURIComponent(rel.slice('/Esoterik-Welt/'.length));
 if(!rel||rel.endsWith('/'))rel+='index.html';
 const file=path.join(ROOT,'dist','Esoterik-Welt',rel);
 const body=await readFile(file);
 res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream'}).end(body);
}catch{res.writeHead(404).end();}});
await new Promise(r=>srv.listen(0,'127.0.0.1',r));
const BASE=`http://127.0.0.1:${srv.address().port}/Esoterik-Welt`;
const browser=await chromium.launch({headless:true});
const result={commit:'ceddc84',browser:browser.version(),base:BASE,axe:[],images:[],errors:[],failures:[]};
await mkdir(OUT,{recursive:true});
const save=()=>writeFile(path.join(OUT,'probe.json'),JSON.stringify(result,null,2));
const spa=['','pendeln','quellen','glossar','methodik','labor','studio','experiment','journal'].map(s=>'/#pendeln'+(s?'/'+s:''));
const docs=['','pendeln','quellen','radiasthesie','orakel','glossar','methodik'].map(s=>'/radiasthesie/'+(s?s+'.html':''));
const photoRoutes=['radiasthesie','pendeln','orakel'].flatMap(s=>['/#pendeln/'+s,'/radiasthesie/'+s+'.html']);
async function pageAt(ctx,route){
 const page=await ctx.newPage();
 page.on('pageerror',e=>result.errors.push({route,error:String(e)}));
 page.on('requestfailed',r=>result.errors.push({route,url:r.url(),error:r.failure()}));
 await page.goto(BASE+route,{waitUntil:'load',timeout:30000});
 if(route.startsWith('/#'))await page.locator('#pendelnRoot h1').waitFor({state:'visible',timeout:10000});
 await page.waitForTimeout(200);
 return page;
}

try {
const ctx=await browser.newContext({viewport:{width:1440,height:900}});
const page=await pageAt(ctx,'/#pendeln/journal');
const steps=[];
for(let i=0;i<40;i++){
 await page.keyboard.press('Tab');
 const rec=await page.evaluate(()=>{const e=document.activeElement,s=getComputedStyle(e);return {id:e.id,tag:e.tagName,type:e.type,outline:s.outline,shadowFocus:e.matches(':focus-within'),focusVisible:e.matches(':focus-visible'),border:s.border};});
 if(rec.type==='date'){
  steps.push({step:i,...rec});
  await page.locator('#'+rec.id).screenshot({path:path.join(OUT,'date-tab-'+i+'.png')});
 }
 if(steps.length&&rec.type!=='date')break;
}
await writeFile(path.join(OUT,'date-focus.json'),JSON.stringify(steps,null,2));
console.log(JSON.stringify(steps));
await ctx.close();
}finally{await browser.close();await new Promise(r=>srv.close(r));}

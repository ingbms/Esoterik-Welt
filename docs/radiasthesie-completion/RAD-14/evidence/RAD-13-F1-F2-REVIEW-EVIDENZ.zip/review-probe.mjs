import {createRequire} from 'node:module';
import {createServer} from 'node:http';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const DIR=path.dirname(fileURLToPath(import.meta.url));
const ROOT=path.join(DIR,'review');
const OUT=path.join(DIR,'review-evidence');
const require=createRequire(path.join(ROOT,'package.json'));
const {chromium}=require('playwright');
const AXE=await readFile('C:/Users/mas/Arbeit/esow-qa-rad13/node_modules/axe-core/axe.min.js','utf8');
const types={'.js':'text/javascript','.json':'application/json','.html':'text/html; charset=utf-8','.css':'text/css','.svg':'image/svg+xml','.avif':'image/avif','.webp':'image/webp','.woff2':'font/woff2'};
const srv=createServer(async(req,res)=>{try{
 let rel=new URL(req.url,'http://localhost').pathname;
 if(!rel.startsWith('/Esoterik-Welt/')){res.writeHead(404).end();return;}
 rel=decodeURIComponent(rel.slice('/Esoterik-Welt/'.length));
 if(!rel||rel.endsWith('/'))rel+='index.html';
 const file=path.join(ROOT,'dist','Esoterik-Welt',rel);
 const body=await readFile(file);
 res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream'}).end(body);
}catch{res.writeHead(404).end();}});
await new Promise(r=>srv.listen(0,'127.0.0.1',r));
const BASE=`http://127.0.0.1:${srv.address().port}/Esoterik-Welt`;
const browser=await chromium.launch({headless:true});
const result={commit:'ceddc84',browser:browser.version(),base:BASE,axe:[],images:[],errors:[],failures:[]};
await mkdir(OUT,{recursive:true});
const save=()=>writeFile(path.join(OUT,'probe.json'),JSON.stringify(result,null,2));
const spa=['','pendeln','quellen','glossar','methodik','labor','studio','experiment','journal'].map(s=>'/#pendeln'+(s?'/'+s:''));
const docs=['','pendeln','quellen','radiasthesie','orakel','glossar','methodik'].map(s=>'/radiasthesie/'+(s?s+'.html':''));
const photoRoutes=['radiasthesie','pendeln','orakel'].flatMap(s=>['/#pendeln/'+s,'/radiasthesie/'+s+'.html']);
async function pageAt(ctx,route){
 const page=await ctx.newPage();
 page.on('pageerror',e=>result.errors.push({route,error:String(e)}));
 page.on('requestfailed',r=>result.errors.push({route,url:r.url(),error:r.failure()}));
 await page.goto(BASE+route,{waitUntil:'load',timeout:30000});
 if(route.startsWith('/#'))await page.locator('#pendelnRoot h1').waitFor({state:'visible',timeout:10000});
 await page.waitForTimeout(200);
 return page;
}
try{
 for(const width of [1440,375]){
  const ctx=await browser.newContext({viewport:{width,height:900},reducedMotion:'reduce'});
  for(const route of [...spa,...docs]){
   const page=await pageAt(ctx,route);
   await page.addScriptTag({content:AXE});
   const axe=await page.evaluate(async()=>{
    const r=await window.axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21a','wcag21aa','wcag22aa','best-practice']}});
    return {version:window.axe.version,violations:r.violations.map(v=>({id:v.id,count:v.nodes.length,targets:v.nodes.map(n=>n.target)})),incomplete:r.incomplete.map(v=>({id:v.id,count:v.nodes.length}))};
   });
   const checks=await page.evaluate(()=>[...document.querySelectorAll('.astro-source-meta a,.rad-photo-credit a,.astro-panel-note a,.rad-media-credits a')].filter(a=>a.getBoundingClientRect().width>0).map(a=>({text:a.textContent.trim().slice(0,40),underline:getComputedStyle(a).textDecorationLine.includes('underline')})));
   result.axe.push({width,route,...axe,checks});
   if(axe.violations.length||checks.some(c=>!c.underline))result.failures.push({type:'a11y',width,route,axe,checks});
   await save();console.log('AXE',width,route,'violations',axe.violations.length,'checked links',checks.length);
   await page.close();
  }
  await ctx.close();
 }
 for(const width of [320,375,414,640,728,729,768,900,1024,1440]){
  const ctx=await browser.newContext({viewport:{width,height:900},deviceScaleFactor:1,reducedMotion:'reduce'});
  for(const route of photoRoutes){
   const page=await pageAt(ctx,route);
   const imgs=page.locator('.rad-plate--photo img');
   if(await imgs.count()!==2)throw new Error('Expected 2 photos '+route);
   for(const img of await imgs.all()){
    await img.scrollIntoViewIfNeeded();
    await img.evaluate(async el=>{el.loading='eager';await Promise.race([el.decode(),new Promise((_,j)=>setTimeout(()=>j(new Error('decode timeout')),10000))]);});
   }
   const rows=await page.evaluate(async()=>{
    const rows=[];
    for(const img of document.querySelectorAll('.rad-plate--photo img')){
     const probe=new Image();probe.src=img.currentSrc;
     await Promise.race([probe.decode(),new Promise((_,j)=>setTimeout(()=>j(new Error('pixel probe timeout')),10000))]);
     const fig=img.closest('figure');
     rows.push({id:fig.id,currentSrc:img.currentSrc,actualPixels:probe.naturalWidth,naturalWidth:img.naturalWidth,cssWidth:img.getBoundingClientRect().width,sizes:fig.querySelector('source').sizes,max:getComputedStyle(fig).maxWidth});
    }
    return rows;
   });
   const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);
   result.images.push({width,route,overflow,rows});
   const bad=rows.filter(r=>!r.actualPixels||r.cssWidth>r.actualPixels+1||r.naturalWidth+8<r.cssWidth);
   if(bad.length||overflow)result.failures.push({type:'image',width,route,bad,overflow});
   if([375,1440].includes(width)&&route==='/#pendeln/radiasthesie')await page.locator('#bild-rad-media-03').screenshot({path:path.join(OUT,'photo-'+width+'.png')});
   await save();console.log('IMG',width,route,rows.map(r=>`${r.cssWidth}/${r.actualPixels}`).join(','),'bad',bad.length);
   await page.close();
  }
  await ctx.close();
 }
}finally{
 await browser.close();await new Promise(r=>srv.close(r));await save();
}
console.log(JSON.stringify({browser:result.browser,axeRuns:result.axe.length,imageRuns:result.images.length,failures:result.failures.length,errors:result.errors.length}));
if(result.failures.length||result.errors.length)process.exitCode=1;
